import React, { useState, useEffect, useRef } from "react";
import css from "./MenuComponent.module.css";
import { FaInfoCircle } from "react-icons/fa";

const MenuComponent = () => {
  const menuItems = {
    1: [
      {
        name: "Avocado Toast Bites",
        price: "$15.00",
        description:
          "Bite-sized toasted artisan bread, fresh avocado spread topped with cherry tomatoes & balsamic glaze",
        allergens: {
          wheat: "toast",
          peanuts: "may contain traces",
        },
        type: "veg",
      },
      {
        name: "Avocado Toast Bites",
        price: "$15.00",
        description:
          "Bite-sized toasted artisan bread, fresh avocado spread topped with cherry tomatoes & balsamic glaze",
        allergens: {
          wheat: "toast",
          peanuts: "may contain traces",
        },
        type: "veg",
      },
      {
        name: "Avocado Toast Bites",
        price: "$15.00",
        description:
          "Bite-sized toasted artisan bread, fresh avocado spread topped with cherry tomatoes & balsamic glaze",
        allergens: {
          wheat: "toast",
          peanuts: "may contain traces",
        },
        type: "veg",
      },
    ],
    2: [
      {
        name: "Veggie Nachos",
        price: "$12.00",
        description:
          "Crispy tortilla chips topped with melted cheese, jalapeños, and guacamole",
        allergens: {
          milk: "cheese",
        },
        type: "veg",
      },
      {
        name: "Avocado Toast Bites",
        price: "$15.00",
        description:
          "Bite-sized toasted artisan bread, fresh avocado spread topped with cherry tomatoes & balsamic glaze",
        allergens: {
          wheat: "toast",
          peanuts: "may contain traces",
        },
        type: "veg",
      },
      {
        name: "Avocado Toast Bites",
        price: "$15.00",
        description:
          "Bite-sized toasted artisan bread, fresh avocado spread topped with cherry tomatoes & balsamic glaze",
        allergens: {
          wheat: "toast",
          peanuts: "may contain traces",
        },
        type: "veg",
      },
    ],
    3: [
      {
        name: "Grilled Sandwich",
        price: "$8.00",
        description:
          "Grilled sandwich with fresh vegetables and cheese, served with a side of fries",
        allergens: {
          wheat: "bread",
          milk: "cheese",
        },
        type: "veg",
      },
      {
        name: "Avocado Toast Bites",
        price: "$15.00",
        description:
          "Bite-sized toasted artisan bread, fresh avocado spread topped with cherry tomatoes & balsamic glaze",
        allergens: {
          wheat: "toast",
          peanuts: "may contain traces",
        },
        type: "veg",
      },
      {
        name: "Avocado Toast Bites",
        price: "$15.00",
        description:
          "Bite-sized toasted artisan bread, fresh avocado spread topped with cherry tomatoes & balsamic glaze",
        allergens: {
          wheat: "toast",
          peanuts: "may contain traces",
        },
        type: "veg",
      },
    ],
  };

  const menuCards = [
    { id: 1, title: "Starters" },
    { id: 2, title: "Snacks" },
    { id: 3, title: "Light Meals" },
  ];

  const [activeCategory, setActiveCategory] = useState(1);
  const [showAllergens, setShowAllergens] = useState({});
  const sectionRefs = useRef([]);

  const handleCardClick = (id) => {
    setActiveCategory(id);
    sectionRefs.current[id - 1]?.scrollIntoView({ behavior: "smooth" });
  };

  const toggleAllergens = (sectionId, itemIndex) => {
    setShowAllergens((prevState) => ({
      ...prevState,
      [sectionId]: prevState[sectionId] === itemIndex ? null : itemIndex,
    }));
  };

  const handleScroll = () => {
    sectionRefs.current.forEach((ref, index) => {
      if (
        ref &&
        ref.getBoundingClientRect().top < window.innerHeight / 2 &&
        ref.getBoundingClientRect().bottom > 0
      ) {
        setActiveCategory(index + 1);
      }
    });
  };

  useEffect(() => {
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  return (
    <div className={css.outerDiv}>
      <div className={css.ttl}>Menu Categories</div>

      {/* Menu Categories */}
      <div className={css.menuCard}>
        {menuCards.map((card) => (
          <div
            key={card.id}
            onClick={() => handleCardClick(card.id)}
            className={`${css.card} ${
              activeCategory === card.id ? css.active : ""
            }`}
          >
            {card.title}
          </div>
        ))}
      </div>

      {/* Menu Sections */}
      <div className={css.sections}>
        {menuCards.map((card) => (
          <div
            key={card.id}
            ref={(el) => (sectionRefs.current[card.id - 1] = el)}
            className={css.section}
          >
            <div className={css.stickyHeading}>{card.title}</div>
            <div className={css.itemsGrid}>
              {menuItems[card.id]?.map((item, index) => (
                <div key={index} className={css.itemCard}>
                  <div className={css.nameAndPrice}>
                    <strong>{item.name}</strong>
                    <p className={css.price}>{item.price}</p>
                  </div>
                  <p className={css.description}>{item.description}</p>
                  <p className={css.typeLabel}>
                    <strong>{item.type === "veg" ? "Veg" : "Non-Veg"}</strong>
                  </p>
                  {showAllergens[card.id] === index && (
                    <div className={css.allergenInfo}>
                      {Object.entries(item.allergens).map(([key, value], idx) => (
                        <p key={idx}>
                          <strong>{key.toUpperCase()}:</strong> {value}
                        </p>
                      ))}
                    </div>
                  )}
                  <div
                    className={css.iconWrapper}
                    onClick={() => toggleAllergens(card.id, index)}
                  >
                    <FaInfoCircle />
                  </div>
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default MenuComponent;
