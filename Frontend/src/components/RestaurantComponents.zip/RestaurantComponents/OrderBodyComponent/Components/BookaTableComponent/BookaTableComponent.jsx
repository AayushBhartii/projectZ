import React, { useState } from "react";
import styles from "./BookaTableComponent.module.css";

const BookaTableComponent = () => {
  const [selectedSlot, setSelectedSlot] = useState(null);
  const [selectedDate, setSelectedDate] = useState("Today");
  const [selectedGuests, setSelectedGuests] = useState("1 guest");
  const [selectedMeal, setSelectedMeal] = useState("Lunch");

  const [isDateDropdownOpen, setIsDateDropdownOpen] = useState(false);
  const [isGuestDropdownOpen, setIsGuestDropdownOpen] = useState(false);
  const [isMealDropdownOpen, setIsMealDropdownOpen] = useState(false);

  const slots = [
    "2:00 PM",
    "2:30 PM",
    "3:00 PM",
    "3:30 PM",
    "4:00 PM",
    "4:30 PM",
    "5:00 PM",
    "5:30 PM",
  ];

  const dates = ["Today", "Tomorrow", "Day after tomorrow"];
  const guests = ["1 guest", "2 guests", "3 guests", "4 guests"];
  const meals = ["Lunch", "Dinner", "Snacks"];

  const handleSlotSelect = (slot) => {
    setSelectedSlot(slot);
  };

  const toggleDateDropdown = () => {
    setIsDateDropdownOpen(!isDateDropdownOpen);
    setIsGuestDropdownOpen(false);
    setIsMealDropdownOpen(false);
  };

  const toggleGuestDropdown = () => {
    setIsGuestDropdownOpen(!isGuestDropdownOpen);
    setIsDateDropdownOpen(false);
    setIsMealDropdownOpen(false);
  };

  const toggleMealDropdown = () => {
    setIsMealDropdownOpen(!isMealDropdownOpen);
    setIsDateDropdownOpen(false);
    setIsGuestDropdownOpen(false);
  };

  const handleDateChange = (date) => {
    setSelectedDate(date);
    setIsDateDropdownOpen(false);
  };

  const handleGuestChange = (guest) => {
    setSelectedGuests(guest);
    setIsGuestDropdownOpen(false);
  };

  const handleMealChange = (meal) => {
    setSelectedMeal(meal);
    setIsMealDropdownOpen(false);
  };

  return (
    <div className={styles.container}>
      {/* Booking Details */}
      <h2 className={styles.heading}>Select your booking details</h2>
      <div className={styles.detailsGrid}>
        <div className={styles.dropdown}>
          <button
            className={styles.dropdownButton}
            onClick={toggleDateDropdown}
          >
            <span>{selectedDate}</span>
            <span>▼</span>
          </button>
          {isDateDropdownOpen && (
            <div className={styles.dropdownOptions}>
              {dates.map((date, index) => (
                <div
                  key={index}
                  className={styles.dropdownOption}
                  onClick={() => handleDateChange(date)}
                >
                  {date}
                </div>
              ))}
            </div>
          )}
        </div>

        <div className={styles.dropdown}>
          <button
            className={styles.dropdownButton}
            onClick={toggleGuestDropdown}
          >
            <span>{selectedGuests}</span>
            <span>▼</span>
          </button>
          {isGuestDropdownOpen && (
            <div className={styles.dropdownOptions}>
              {guests.map((guest, index) => (
                <div
                  key={index}
                  className={styles.dropdownOption}
                  onClick={() => handleGuestChange(guest)}
                >
                  {guest}
                </div>
              ))}
            </div>
          )}
        </div>

        <div className={styles.dropdown}>
          <button
            className={styles.dropdownButton}
            onClick={toggleMealDropdown}
          >
            <span>{selectedMeal}</span>
            <span>▼</span>
          </button>
          {isMealDropdownOpen && (
            <div className={styles.dropdownOptions}>
              {meals.map((meal, index) => (
                <div
                  key={index}
                  className={styles.dropdownOption}
                  onClick={() => handleMealChange(meal)}
                >
                  {meal}
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Select Slot */}
      <h3 className={styles.subheading}>Select slot</h3>
      <div className={styles.slotsGrid}>
        {slots.map((slot, index) => (
          <button
            key={index}
            className={`${styles.slotButton} ${
              selectedSlot === slot ? styles.selectedSlot : ""
            }`}
            onClick={() => handleSlotSelect(slot)}
          >
            {slot}
            <div className={styles.offersText}>2 offers</div>
          </button>
        ))}
      </div>

      {/* Proceed Button */}
      <button
        className={`${styles.proceedButton} ${
          selectedSlot ? styles.proceedEnabled : styles.proceedDisabled
        }`}
        disabled={!selectedSlot}
      >
        Proceed to cart
      </button>
    </div>
  );
};

export default BookaTableComponent;
